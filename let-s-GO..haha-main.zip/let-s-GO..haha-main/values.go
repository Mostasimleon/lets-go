package main
import "fmt"

func main(){
	text := "Hello, "
	name := "World!"

	fmt.Println(text + name)

	fmt.Println("This is Joy's second try at learning Go.")
}

